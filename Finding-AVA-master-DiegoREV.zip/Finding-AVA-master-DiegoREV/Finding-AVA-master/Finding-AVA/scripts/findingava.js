var scn = null;

//event that runs when the content is loaded
document.addEventListener('DOMContentLoaded', function() {
    scn = document.getElementById('avasscene');
    addPage('welcome');
});

//Gets the content of the level to load
var getsLevelContent = function(name){

    var req = new XMLHttpRequest();
    if(req != null){
        req.open('GET', 'scenes/'+name+'.txt',true);
        req.onreadystatechange = handler;
        req.send();
    }
    else{
        console.log('Request Error');
    }

    function handler(){
        if(req.readyState == 4){
            if(req.status == 200)
                {
                    document.getElementById(name+'_page').innerHTML = req.responseText;
                }
        }
    }
};

var addPage = function(name){
    getsLevelContent(name);
    var newPage = document.createElement('a-entity');
    newPage.setAttribute('id', name + '_page');
    scn.appendChild(newPage);
};

//removes a page
var removePage = function(name){
    var p = document.getElementById(name+'_page');
    scn.removeChild(p);
};